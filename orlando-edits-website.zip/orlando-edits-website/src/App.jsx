import React, { useState } from 'react';

export default function App() {
  const [activeTab, setActiveTab] = useState('cars');

  // Mock data for sections
  const carsData = [
    { id: 1, name: "BeamNG Civic Street Build", image: "https://i.imgur.com/1O0PPKV.jpg"  },
    { id: 2, name: "BeamNG Civic Drag Build", image: "https://i.imgur.com/X1d8Jkh.jpg"  },
    { id: 3, name: "BeamNG Civic VTEC Swap", image: "https://i.imgur.com/zGqcyLt.jpg"  },
    { id: 4, name: "BeamNG Turbocharged Civic", image: "https://i.imgur.com/cXRln0l.jpg"  },
    { id: 5, name: "BeamNG Stanced Civic", image: "https://i.imgur.com/D3xO0LF.jpg"  },
    { id: 6, name: "BeamNG Drift Ready Civic", image: "https://i.imgur.com/OLwJWCY.jpg"  }
  ];

  const beamngTracksData = [
    { id: 1, name: "Salinas Speedway", image: "https://i.imgur.com/lCeeMFt.jpg"  },
    { id: 2, name: "Salinas Speedway", image: "https://i.imgur.com/Pf9zrO3.jpg"  },
    { id: 3, name: "Salinas Speedway", image: "https://i.imgur.com/oWQ456J.jpg"  },
    { id: 4, name: "Salinas Speedway", image: "https://i.imgur.com/1hzD8dZ.jpg"  },
    { id: 5, name: "Salinas Speedway", image: "https://i.imgur.com/Z2Vkl7x.jpg"  }
  ];

  const assettoCarsData = [
    { id: 1, name: "Chapulin Performance Civic", image: "https://i.imgur.com/aOdwvtf.jpg"  },
    { id: 2, name: "Mitsubishi Mirage Calle", image: "https://i.imgur.com/A6rfsAf.jpg"  },
    { id: 3, name: "Acura Drag Mod", image: "https://i.imgur.com/fubGsxS.jpg"  },
    { id: 4, name: "Venenum Racing", image: "https://i.imgur.com/hlrWIJa.jpg"  },
    { id: 5, name: "Variety of Cars", image: "https://i.imgur.com/iVRtxLs.jpg"  },
    { id: 6, name: "Honda Civic Pack", image: "https://i.imgur.com/hhz1XiE.jpg"  }
  ];

  const assettoTracksData = [
    { id: 1, name: "Orlando Speedworld", image: "https://i.imgur.com/7EQWX4J.jpg"  },
    { id: 2, name: "Salinas Speedway PR", image: "https://i.imgur.com/bJFsug0.jpg"  },
    { id: 3, name: "Rio Drag Park Juana Diaz", image: "https://i.imgur.com/zMgndYy.jpg"  },
    { id: 4, name: "Arecibo Motorsport", image: "https://i.imgur.com/l7A91VG.jpg"  },
    { id: 5, name: "Aibonito Chinchorreo", image: "https://i.imgur.com/7p6azAe.jpg"  }
  ];

  return (
    <div className="bg-black text-white min-h-screen font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-gray-800 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <img src="https://i.imgur.com/BlhVawC.png"  alt="Logo" className="h-8 w-auto" />
          <span className="text-xl font-bold">D&O Racing</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm uppercase tracking-wider">
          <button onClick={() => setActiveTab('cars')} className={`hover:text-red-500 transition-colors ${activeTab === 'cars' ? 'text-red-500' : ''}`}>BeamNG Cars</button>
          <button onClick={() => setActiveTab('beamng-tracks')} className={`hover:text-red-500 transition-colors ${activeTab === 'beamng-tracks' ? 'text-red-500' : ''}`}>BeamNG Tracks</button>
          <button onClick={() => setActiveTab('assetto-cars')} className={`hover:text-red-500 transition-colors ${activeTab === 'assetto-cars' ? 'text-red-500' : ''}`}>Assetto Cars</button>
          <button onClick={() => setActiveTab('assetto-tracks')} className={`hover:text-red-500 transition-colors ${activeTab === 'assetto-tracks' ? 'text-red-500' : ''}`}>Assetto Tracks</button>
        </div>
        <button className="md:hidden text-gray-400 hover:text-white">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-16 px-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 h-full w-full bg-gradient-to-br from-red-500 via-transparent to-blue-500"></div>
        </div>
        <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6 tracking-tight">
          Premium <span className="text-red-500">Vehicle & Track</span> Mods
        </h1>
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-300 mb-10">
          High-quality BeamNG and Assetto Corsa mods meticulously crafted for performance, realism, and customization.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <a href="https://www.patreon.com/OrlandoEdits"  target="_blank" rel="noopener noreferrer" className="px-8 py-3 rounded-full bg-red-600 hover:bg-red-700 text-white font-semibold shadow-lg hover:shadow-red-500/25 transition-all transform hover:-translate-y-0.5">
            Join Patreon
          </a>
          <a href="https://discord.gg/efQbWaKC"  target="_blank" rel="noopener noreferrer" className="px-8 py-3 rounded-full border border-gray-600 hover:border-white text-gray-300 hover:text-white font-semibold transition-colors">
            Discord Community
          </a>
        </div>
      </section>

      {/* Content Sections */}
      <main className="px-6 pb-24">
        {/* BEAMNG CARS SECTION */}
        {activeTab === 'cars' && (
          <section className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">BeamNG Cars</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {carsData.map((car) => (
                <div key={car.id} className="group overflow-hidden rounded-lg bg-gray-900/50 border border-gray-800 hover:border-red-500 transition-all duration-300">
                  <div className="relative overflow-hidden aspect-video">
                    <img src={car.image} alt={car.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-white font-semibold">{car.name}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* BEAMNG TRACKS SECTION */}
        {activeTab === 'beamng-tracks' && (
          <section className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">BeamNG Tracks</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {beamngTracksData.map((track) => (
                <div key={track.id} className="group overflow-hidden rounded-lg bg-gray-900/50 border border-gray-800 hover:border-red-500 transition-all duration-300">
                  <div className="relative overflow-hidden aspect-video">
                    <img src={track.image} alt={track.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-white font-semibold">{track.name}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ASSETTO CARS SECTION */}
        {activeTab === 'assetto-cars' && (
          <section className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Assetto Corsa Cars</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {assettoCarsData.map((car) => (
                <div key={car.id} className="group overflow-hidden rounded-lg bg-gray-900/50 border border-gray-800 hover:border-red-500 transition-all duration-300">
                  <div className="relative overflow-hidden aspect-video">
                    <img src={car.image} alt={car.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-white font-semibold">{car.name}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ASSETTO TRACKS SECTION */}
        {activeTab === 'assetto-tracks' && (
          <section className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Assetto Corsa Tracks</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {assettoTracksData.map((track) => (
                <div key={track.id} className="group overflow-hidden rounded-lg bg-gray-900/50 border border-gray-800 hover:border-red-500 transition-all duration-300">
                  <div className="relative overflow-hidden aspect-video">
                    <img src={track.image} alt={track.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-white font-semibold">{track.name}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <img src="https://i.imgur.com/BlhVawC.png"  alt="Logo" className="h-6 w-auto" />
              <span className="text-lg font-bold">D&O Racing</span>
            </div>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-400">
              <a href="https://www.patreon.com/OrlandoEdits"  target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Patreon</a>
              <a href="https://discord.gg/efQbWaKC"  target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Discord</a>
              <a href="https://www.instagram.com/domods21/"  target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Instagram</a>
              <a href="https://www.youtube.com/@xOrlandoPrVLTx/"  target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">YouTube</a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} D&O Racing. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}